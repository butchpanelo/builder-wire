﻿using System;
using System.IO;
using WordMatch;

namespace BuilderWireCodingChallenge
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                if(args.Length<2)
                {
                    ShowSyntax();
                }

                var (wordsFilename, articleFilename, outputFilename) = GetParams(args);

                if(wordsFilename==null || articleFilename==null)
                {
                    ShowSyntax();
                }

                //string[] words = File.ReadAllLines(wordsFilename);
                //string article = File.ReadAllText(articleFilename);
                //WordMatcher wordMatcher = new WordMatcher(words,article);
                WordMatcher wordMatcher = new WordMatcher(wordsFilename, articleFilename);
                var dict = wordMatcher.ProcessToDictionary();
                string[] contents = WordMatcher.ToLetterBulletedList(dict);
                GenerateOutput(outputFilename, contents);

            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
            Environment.Exit(0);
        }

        private static void ShowSyntax()
        {
            Console.WriteLine("Usage: ");
            Console.WriteLine("BuilderWireCodingChallenge /w:{words filename} /a:{article filename} /out:{output filename}");
            Console.WriteLine("/out parameter is Optional, outputs to screen when not supplied");
            Console.ReadLine();
            Environment.Exit(0);
        }

        private static void GenerateOutput(string filename, string[] contents)
        {
            try 
            {
                if (filename != null) 
                {
                    File.WriteAllLines(filename, contents);
                }
                else 
                {
                    OutputToScreen(contents);
                }
            }
            catch 
            {
                if(filename!=null)
                {
                    Console.WriteLine("File write error, redirecting output to screen.");
                }
                OutputToScreen(contents);
            }
        }

        private static void OutputToScreen(string[] contents)
        {
            foreach (string text in contents)
            {
                Console.WriteLine(text);
            }
        }

        private static (string wordsFilename, string articleFilename, string outputFilename) 
        GetParams(string[] args)
        {
            string wordsFn = null;
            string articleFn = null;
            string outputFn = null;

            foreach(string arg in args)
            {
                string _arg = arg.ToLower();
                if(_arg.StartsWith("/w:"))
                {
                    wordsFn = GetFilename(arg);
                }
                else if (_arg.StartsWith("/a:"))
                {
                    articleFn = GetFilename(arg);
                }
                else if (_arg.StartsWith("/out:"))
                {
                    outputFn = GetFilename(arg);
                }
            }
            return (wordsFn, articleFn, outputFn);
        }

        private static string GetFilename(string arg)
        {
            int index = arg.IndexOf(":");
            if(index>-1)
            {
                return arg.Substring(index + 1);
            }
            return null;
        }
    }
}
