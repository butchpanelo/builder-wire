﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Reflection;

namespace WordMatch
{
    public class WordMatcher
    {
        private string[] Words { get; set; }
        private string LowerCaseParagraph { get; set; }

        private readonly WordFinder _wordFinder;

        public WordMatcher(string[] words, string article, WordFinder wordFinder)
        {
            string _classname = MethodBase.GetCurrentMethod().DeclaringType.Name;
            Words = words ?? throw new ArgumentNullException($"words [{_classname}]");
            LowerCaseParagraph = article ?? throw new ArgumentNullException($"article [{_classname}]");
            _wordFinder = wordFinder ?? throw new ArgumentNullException($"wordFinder [{_classname}]");
            LowerCaseParagraph = LowerCaseParagraph.ToLower();
        }

        public WordMatcher(string[] words, string article)
            : this(words, article, new WordFinder()) { }

        public WordMatcher(string wordsFilename, string articleFilename, WordFinder wordFinder)
            : this(words: File.ReadAllLines(wordsFilename),
                  article: File.ReadAllText(articleFilename),
                  wordFinder: wordFinder)
        { }

        public WordMatcher(string wordsFilename, string articleFilename)
            : this(words: File.ReadAllLines(wordsFilename),
                  article: File.ReadAllText(articleFilename),
                  wordFinder: new WordFinder())
        { }

        private string _sentenceSeparator;
        public string SentenceSeparator
        {
            get {
                return (_sentenceSeparator == null || _sentenceSeparator.Trim().Length==0) ? ".!?" : _sentenceSeparator;
            }
            set { _sentenceSeparator = value; }
        }


        public Dictionary<string, (int freq, int[] sentenceIndex)> 
        ProcessToDictionary()
        {
            string[] sentences = TransposeParagraph();

            Dictionary<string, (int freq, int[] sentenceIndex)> dict = new Dictionary<string, (int freq, int[] sentenceIndex)>();
            
            Words.ToList().ForEach(word =>
            {
                if(!dict.ContainsKey(word))
                {
                    var (freq, sentenceIndex) = _wordFinder.FindInParagraph(word.ToLower(), sentences);
                    dict.Add(word, (freq, sentenceIndex));
                }
            });

            return dict;
        }

        public static string[] ToLetterBulletedList(Dictionary<string, (int freq, int[] sentenceIndex)> words)
        {
            List<string> output = new List<string>();
            var bullet = new LetterBullet('a', 'y');
            words.Keys.ToList().ForEach(key =>
            {
                var record = $"{bullet.Next()} {key} {{{words[key].freq}:{string.Join(",", words[key].sentenceIndex) }}}";
                output.Add(record);
            });
            return output.ToArray();
        }

        /**
        -- replaces the dotted words (e.g. "mr." with "mr_")
        -- returns array of sentences
        **/
        private string[] TransposeParagraph()
        {

            var dottedWords = Words.Where(word => word.Contains("."));
            this.LowerCaseParagraph = this.LowerCaseParagraph.Replace(',', ' '); // ignore commas
            foreach(string word in dottedWords)
            {
                int startIndex = 0;
                while (startIndex < LowerCaseParagraph.Length)
                {
                    var index = LowerCaseParagraph.IndexOf(word, startIndex);

                    if (index > -1)
                    {
                        var spaceIndex = index + word.Length;
                        if (spaceIndex == LowerCaseParagraph.Length ||
                            LowerCaseParagraph.Substring(spaceIndex, 1) == " ")
                        {
                            string replacement = word.Replace(".", "_");
                            LowerCaseParagraph = string.Concat(
                                index - 1 > -1 ? LowerCaseParagraph.Substring(0, index) : "",
                                replacement,
                                spaceIndex < LowerCaseParagraph.Length ? LowerCaseParagraph.Substring(spaceIndex) : "");
                        }
                        if(spaceIndex==LowerCaseParagraph.Length)
                        {
                            break;
                        }
                        startIndex += spaceIndex;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            return this.LowerCaseParagraph.Split(SentenceSeparator.ToCharArray());
        }
    }
}
