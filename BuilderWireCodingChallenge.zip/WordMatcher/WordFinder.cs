﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WordMatch
{
    public class WordFinder: IWordFinder
    {
        public (int freq, int[] sentenceIndex) FindInParagraph(string searchText, string[] sentences)
        {
            List<int> sentenceIndex = new List<int>();
            int freq = 0;
            string search = searchText.Replace(".", "_");

            for (int i = 0; i < sentences.Length; i++)
            {
                var wordCount = CountWords(search, sentences[i]);
                freq += wordCount;
                while (wordCount-- > 0)
                {
                    sentenceIndex.Add(i + 1);
                }
            }
            return (freq, sentenceIndex.ToArray());
        }

        private static int CountWords(string searchText, string sentence)
        {
            string[] words = sentence.Split(' ');
            return words.Where(word => word == searchText).Count();
        }
    }
}
