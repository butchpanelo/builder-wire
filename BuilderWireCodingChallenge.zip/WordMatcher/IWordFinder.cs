﻿using System;

namespace WordMatch
{
    interface IWordFinder
    {
        (int freq, int[] sentenceIndex) FindInParagraph(string searchText, string[] sentences);
    }
}
