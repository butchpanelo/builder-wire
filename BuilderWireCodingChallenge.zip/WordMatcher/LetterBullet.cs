﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WordMatch
{
    public class LetterBullet
    {
        public LetterBullet(char charFrom, char charTo)
            : this(charFrom, charTo, ".") { }

        public LetterBullet(char charFrom, char charTo, string suffix)
        {
            this.CharFrom = charFrom;
            this.CharTo = charTo;
            this.CurrentChar = charFrom;
            this.Suffix = suffix;
        }

        private char CharFrom { get; set; }
        private char CharTo { get; set; }
        private char CurrentChar { get; set; }
        private string Suffix { get; set; }
        private string currentBullet;

        public string Next()
        {
            if (currentBullet == null)
            {
                currentBullet = CurrentChar++.ToString();
                return currentBullet + Suffix;
            }
            if (CurrentChar > CharTo)
            {
                CurrentChar = CharFrom;
                currentBullet = CurrentChar.ToString().PadRight(currentBullet.Length + 1, CurrentChar);
            }
            else
            {
                currentBullet = "".PadRight(currentBullet.Length, CurrentChar);
            }
            CurrentChar++;
            return currentBullet + Suffix;
        }
    }
}
