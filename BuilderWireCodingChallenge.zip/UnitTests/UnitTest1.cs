﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WordMatch;

namespace UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        readonly string testArticle = "This is what I learned from Mr. Jones about a paragraph. A paragraph is a group of words put together to form a group that is usually longer than a sentence. Paragraphs are often made up of several sentences. There are usually between three and eight sentences. Paragraphs can begin with an indentation, or by missing a line out, and then starting again. This makes it easier to see when one paragraph ends and another begins. In most organized forms of writing, such as essays, paragraphs contain a topic sentence. This topic sentence of the paragraph tells the reader what the paragraph will be about. Essays usually have multiple paragraphs that make claims to support a thesis statement, which is the central idea of the essay. Paragraphs may signal when the writer changes topics. Each paragraph may have a number of sentences, depending on the topic. I can now write topics on sports e.g. basketball, football, baseball and submit it to Mrs. Smith.";
        readonly string[] testWords = File.ReadAllLines("words.txt");

        [TestMethod]
        public void Param_words_WhenNull_ShowThrowArgumentNullException()
        {
            string[] words = null;
            string article = "Hello World!";

            Assert.ThrowsException<ArgumentNullException>(() => new WordMatcher(words, article));
        }

        [TestMethod]
        public void Param_article_WhenNull_ShowThrowArgumentNullException()
        {
            string[] words = { "a", "b", "c" };
            string article = null;

            Assert.ThrowsException<ArgumentNullException>(() => new WordMatcher(words, article));
        }

        [TestMethod]
        public void Param_wordsFilename_WhenFileDoesNotExists_ShowThrowException()
        {
            string wordsFilename = "somefilename1.txt";
            string articleFilename = "somefilename2.txt";

            Assert.ThrowsException<FileNotFoundException>(() => new WordMatcher(wordsFilename, articleFilename));
        }

        [TestMethod]
        public void Param_articleFilename_WhenFileDoesNotExists_ShowThrowException()
        {
            string wordsFilename = "words.txt";
            string articleFilename = "somefilename2.txt";

            Assert.ThrowsException<FileNotFoundException>(() => new WordMatcher(wordsFilename, articleFilename));
        }

        [TestMethod]
        public void Output_Should_Include_Every_Word_From_Input()
        {
            var wordMatcher = new WordMatcher(testWords, testArticle);
            var dict = wordMatcher.ProcessToDictionary();

            testWords.ToList().ForEach(word => {
                Assert.IsTrue(dict.ContainsKey(word), $"Word \"{word}\" is not in the dictionary.");
            });
        }

        [TestMethod]
        public void Words_Frequency_Should_Be_Greater_Than_Zero()
        {
            var wordMatcher = new WordMatcher(testWords, testArticle);

            var dict = wordMatcher.ProcessToDictionary();

            testWords.ToList().ForEach(word => {
                (int freq, int[] sentenceIndex) = dict[word];
                Assert.IsTrue(freq > 0, $"Word \"{word}\" count is not greater than zero.");
            });
        }

        [TestMethod]
        public void Output_Should_Equal_Expected_Results_Random_Sampling()
        {
            (string key, string value)[] expected = {
                (key: "this", value:"a. this {3:1,6,8}"),
                (key: "a", value: "j. a {9:1,2,2,2,2,5,7,9,11}"),
                (key: "e.g.", value: "uuuu. e.g. {1:12}"),
                (key: "the", value: "rrr. the {7:8,8,8,9,9,10,11}"),
                (key: "sentences", value: "ee. sentences {3:3,4,11}"),
                (key: "mrs.", value: "aaaaa. mrs. {1:12}")
            };

            var wordMatcher = new WordMatcher(testWords, testArticle);

            var dict = wordMatcher.ProcessToDictionary();
            var outputList = WordMatcher.ToLetterBulletedList(dict);
            expected.ToList().ForEach(item => {
                int index = outputList.ToList().FindIndex(x => x == item.value);
                Assert.IsTrue(index>-1, $"Word \"{item.key}\" expected and actual results are different.");
            });
        }
    }
}
